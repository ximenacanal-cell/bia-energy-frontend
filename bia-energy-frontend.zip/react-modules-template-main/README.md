# Bia Energy — Frontend Reto 3

Frontend en React + TypeScript que consume los endpoints del microservicio construido en el Reto 2.

## Stack

- React 19 + TypeScript
- Material UI 7
- SCSS Modules con design tokens de Bia
- TanStack Query
- React Router v7

## Funcionalidades

- **Clientes**: listar, buscar, crear y eliminar
- **Productos**: listar en tarjetas, buscar, crear y eliminar
- Estado de carga con skeleton animado
- Manejo de errores con reintentar
- Responsive (funciona en celular)

## Estructura relevante

```
src/
├── services/
│   └── api.ts                  ← Capa de servicios (fetch al backend)
├── modules/
│   └── notifications/
│       ├── index.ts
│       └── ui/pages/
│           ├── NotificationsPage.tsx        ← Página principal
│           └── NotificationsPage.module.scss
```

## Cómo correr

### 1. Instalar dependencias
```bash
npm install
```

### 2. Configurar el backend
Asegúrate de que el backend del Reto 2 esté corriendo en `http://localhost:3001`.

El archivo `.env.development` ya está configurado:
```
REACT_APP_API_URL=http://localhost:3001
```

### 3. Levantar el frontend
```bash
npm start
```

Abre [http://localhost:3000](http://localhost:3000).

## Endpoints consumidos

| Método | Endpoint        | Descripción              |
|--------|-----------------|--------------------------|
| GET    | /clientes       | Listar todos los clientes |
| POST   | /clientes       | Crear un cliente          |
| DELETE | /clientes/:id   | Eliminar un cliente       |
| GET    | /productos      | Listar todos los productos |
| POST   | /productos      | Crear un producto         |
| DELETE | /productos/:id  | Eliminar un producto      |
| GET    | /health         | Health check              |

## Endpoints adicionales (implementados, listos para conectar UI)
- PUT /clientes/:id
- PUT /productos/:id
- GET /pedidos
